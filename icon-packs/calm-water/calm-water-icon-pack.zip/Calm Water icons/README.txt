Calm Water icon pack from Honest Little Apps (https://honestlittleapps.github.io/icon-packs/calm-water/).
How to use: https://honestlittleapps.github.io/icon-packs/how-to-change-app-icons-on-iphone/
Free for personal use. Please don't resell.
